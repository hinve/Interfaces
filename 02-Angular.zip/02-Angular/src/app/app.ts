import { Component, NgModule, signal } from '@angular/core';
import { ContadorModule } from './contador/contador.module';
import { HeroesModule } from './heroes.component/heroes.module';


@Component({
  selector: 'app-root',
  imports: [ContadorModule, HeroesModule],
  templateUrl: './app.html',
  styleUrl: './app.css'
})

export class App {

}
